#include <Arduino.h>
#include "Datastorage.h"
#include <FRAM_MB85RC_I2C.h>

//Toolhead Timer, what toolhead is selected is transmit over CANbus, Datastorage function will handle it


//Keep track of toolhead time in seconds, convert to Human readable when OLED needs it
IntervalTimer Secondcounter;
volatile uint32_t Seconds = 0; 

//Buzzer Settings



/* Using I2C Port 0
   Connect SCL    Pin 19
   Connect SDA    Pin 18
   Connect VDD    5.0V DC
   Connect VSS    GND
   SDA/SCL        4k7 Pullups to 3V3 
   */


const word FRAMAdr = 0x50; //Not used as this is the default Adress in the used Libary
boolean wp = false;
int FRAMpin = 13;
int16_t FRAMdensity = 64; //64kbit
FRAM_MB85RC_I2C fram(FRAMAdr, wp, FRAMpin, FRAMdensity);

byte resultw, resultr; 
uint8_t writevalue = 0xBE;
uint16_t writevalue2 = 0xBEEF;
uint8_t readvalue = 0xEF; // at the end, readvalue should be equal to writevalue
uint16_t readvalue2 = 0xDEAD;

void InitFRAM(){
Wire.begin();
fram.begin();
Serial.print("Checked Device answer: ");
Serial.println(fram.checkDevice());
}

void IncSecCounter(){
   Seconds = Seconds + 1;
}

uint32_t GetDword(FRAMAdress32 Adress){
   uint32_t output = 0;
   uint16_t tempadr = 0; 
   tempadr = Adress * 4; //Offset Baseadress by *4 to have 4byte slots
   

   fram.readLong(tempadr,&output);
  return output;
}

void SetDword(FRAMAdress32 Adress, uint32_t Data){
   uint16_t tempadr = 0;
   tempadr = Adress * 4; //Offset Baseadress by *4 to have 4byte slots
  
   fram.writeLong(tempadr,Data);
  
}

void framtest(){
//random addresses to write from
uint16_t writeaddress = 0x025; // Beginning of the memory map
uint16_t writeaddress2 = (FRAMdensity * 128) - 80; // calculated regarding density to hit more or less the end of memory map


   //--------------------------- First run, beginning of memory map ---------------------
	Serial.println("1st test");
	Serial.print("Writing at location 0x");
	Serial.println(writeaddress, HEX);
	
	Serial.println("Writing...");
	resultw = fram.writeByte(writeaddress, writevalue);
	Serial.println("Reading...");
	resultr = fram.readByte(writeaddress, &readvalue);
	
	Serial.print("Written value 0x");
	Serial.println(writevalue, HEX);
	
	Serial.print("Read value 0x");
	Serial.println(readvalue, HEX);
	
	if (writevalue == readvalue) {
		Serial.println("Write Byte test : OK");
	}
	else {
		Serial.println("Write Byte test : NOT OK");
	}
	Serial.println(".... ....");
	
//-------------------------- Second run, end of the memory map -----------------------
 	Serial.println("2nd test");   
	Serial.print("Writing at location 0x");
	Serial.println(writeaddress2, HEX);
	
	Serial.println("Writing...");
	resultw = fram.writeWord(writeaddress2, writevalue2);
	Serial.println("Reading...");
	resultr = fram.readWord(writeaddress2, &readvalue2);
	
	Serial.print("Written value 0x");
	Serial.println(writevalue2, HEX);
	
	Serial.print("Read value 0x");
	Serial.println(readvalue2, HEX);
	
	if (writevalue2 == readvalue2) {
		Serial.println("Write word test : OK");
	}
	else {
		Serial.println("Write word test : NOT OK");
	}
	Serial.println(".... ....");

   delay(10000);
}

