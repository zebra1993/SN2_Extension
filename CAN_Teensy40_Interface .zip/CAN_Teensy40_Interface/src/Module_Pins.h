#ifndef MODULE_PINS_H_
#define MODULE_PINS_H_


//CAN2 Snapmaker
//0 Can2_RX
//1 Can2_TX

//UserLED
#define LED1 2 //Silkscreen D2
#define LED2 3 //Silkscreen D3
#define LED3 4 //Silkscreen D4

//5 Not used

//Adressable RGB
#define RGB_DATA_PIN 6 //Dout on J12

//Serial2 Port open to user (J14)
//7 Serial2_RX
//8 Serial2_TX

//Buzzer
#define Buzzer_out 9

//ADC SPI
#define ADC_CS 10 //Also BuiltinLED so every ADC read the LED blinks (neat feature imo)
//11 ADC_MOSI
//12 ADC_MISO
//13 ADC_SCK

//Buttons
#define Button1 14 //Silkscreen SW2
#define Button2 15 //Silkscreen SW3

//Rotary Encoder 1
#define RotEnc_B 16
#define RotEnc_A 17

//FRAM
//18 FRAM_SDA
//19 FRAM_SCL

//20 not used

//Rotary Encoder 2
#define RotEnc_Sw 21

//Can1 Extension modules
//22 Can1_TX
//23 Can1_RX

//Underside
//24-39 not used to keep the PCB simpler and no SDCard was planed


#endif