#include <Arduino.h>
#include <Adafruit_MCP3008.h>
#include "Tempcalc.h" 
#include "Module_Pins.h"


Adafruit_MCP3008 adc;

/*
1/T = 1/TO + (1/β) ⋅ ln (R/RO)

β, 
Ro = 10
R25 = 10k

*/

//ADC stuff
//Resistor constants per Datasheet
int B = 3984; //Beta Constant B25/85 =3984 
//Both Resistor Values in Ohm
int R0 = 10000;  //@25°C
float To = 273.15 + 25; //Nominal Ambientemperature in Kelvin
int Rser = 27000;//27k Devider resistor
float Vref = 3.3; //Volt
const int active_channels = 7; //only 6 channels are used, 2 spare fo user or if killed :D


//Find maxTemp stuff
int ADCreadings[active_channels] = {};



void InitADC(){

  // (sck, mosi, miso, cs);
  //adc.begin(13, 11, 12, 10);
    adc.begin();
}


int GetTemp(LinearTempSens ch){
float Vmes = adc.readADC(ch)*(Vref/1023);
float R = (Vmes * Rser) / (Vref - Vmes);
float Temp = 1/((1/To)+((log(R/R0))/B));
float Tc = Temp-273.15; //Form Kelvin back to °C
if (Tc > 250){
Tc=250; //Limit Tc to 250°C. As my sensor is rated only for 180 and an Axis shouldnt exeed this anyway without damage
}
return Tc;
};

float GetVoltage(LinearTempSens ch)//Max Vin is 3.3V!
{
float Voltage = adc.readADC(ch)*(Vref/1023); //Convert 

return Voltage;
};

int GethighestTemp_C(){
// Serial.println("ADCReadings");
 /* for (size_t i = 0; i < active_channels; i++)
  {
    Serial.print(ADCreadings[i]);
    Serial.print(" - ");
  }*/


  byte maxindex = 0;
  int maxTemp = ADCreadings[maxindex];

for (size_t i = 0; i < active_channels; i++)
{
  switch (i)
  {
  case 0:
    ADCreadings[i] = GetTemp(X_Axis_1);
    break;

  case 1:
    ADCreadings[i] = GetTemp(Y_Axis_1);
    break;

  case 2:
    ADCreadings[i] = GetTemp(Y_Axis_2);
    break;

  case 3:
    ADCreadings[i] = GetTemp(Z_Axis_1);
    break;

  case 4:
    ADCreadings[i] = GetTemp(Z_Axis_2);
    break;

  case 5:
    ADCreadings[i] = GetTemp(Ambient);
    break;

  case 6:
    ADCreadings[i] = GetTemp(Spare_1);
    break;

  case 7:
    ADCreadings[i] = GetTemp(Spare_2);
    break;

  default:
    break;
  }
}



 for (byte i = 0; i < active_channels; i++)
 {
   if (ADCreadings[i] > maxTemp){
     maxTemp = ADCreadings[i];
     maxindex = i;
   }
 }

    /* //GetData in ADCreadings array
  Serial.println("ADCReadings");
  for (size_t i = 0; i < active_channels; i++)
  {
    Serial.print(ADCreadings[i]);
    Serial.print(" - ");
  }
  
 Serial.print("Maxvalue: ");
 Serial.println(maxTemp); //Get Current highest Temp
 Serial.print("Maxindex: ");
 Serial.println(maxindex); //Get index of highest Temp
*/

return maxTemp;
}

int GethighestTemp_Index(){
/*  
  Serial.println("ADCReadings");
  for (size_t i = 0; i < active_channels; i++)
  {
    Serial.print(ADCreadings[i]);
    Serial.print(" - ");
  }
*/

  byte maxindex = 0;
  int maxTemp = ADCreadings[maxindex];

for (size_t i = 0; i < active_channels; i++)
{
  switch (i)
  {
  case 0:
    ADCreadings[i] = GetTemp(X_Axis_1);
    break;

  case 1:
    ADCreadings[i] = GetTemp(Y_Axis_1);
    break;

  case 2:
    ADCreadings[i] = GetTemp(Y_Axis_2);
    break;

  case 3:
    ADCreadings[i] = GetTemp(Z_Axis_1);
    break;

  case 4:
    ADCreadings[i] = GetTemp(Z_Axis_2);
    break;

  case 5:
    ADCreadings[i] = GetTemp(Ambient);
    break;

  case 6:
    ADCreadings[i] = GetTemp(Spare_1);
    break;

  case 7:
    ADCreadings[i] = GetTemp(Spare_2);
    break;

  default:
    break;
  }
}



 for (byte i = 0; i < active_channels; i++)
 {
   if (ADCreadings[i] > maxTemp){
     maxTemp = ADCreadings[i];
     maxindex = i;
   }
 }

    /* //GetData in ADCreadings array
  Serial.println("ADCReadings");
  for (size_t i = 0; i < active_channels; i++)
  {
    Serial.print(ADCreadings[i]);
    Serial.print(" - ");
  }
  
 Serial.print("Maxvalue: ");
 Serial.println(maxTemp); //Get Current highest Temp
 Serial.print("Maxindex: ");
 Serial.println(maxindex); //Get index of highest Temp
*/

return maxindex;
}

