//Libary includes
#include <Arduino.h>
#include <Wire.h>
#include <Adafruit_I2CDevice.h>
#include <Adafruit_SSD1306.h>
#include <encoder.h>
#include <LightChrono.h>

//Custom includes
#include "oledscreen.h"
#include "Module_Pins.h"
#include "Tempcalc.h"

//Display stuff
#define SCREEN_WIDTH 128 // OLED display width, in pixels
#define SCREEN_HEIGHT 32 // OLED display height, in pixels

Adafruit_SSD1306 displ(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire);

//If display is dirty, refresh, else skip update
bool displaydirty;
//selected entries for the Menu UI to show where you are in the Menutree (Noika Style)
int menu_chapter = 0;
int menu_page = 0;
int menu_paragrapth = 0;
//Counters for navigation
int current_menu_chapter = 0;
int current_menu_page = 0;
int current_menu_paragrapth = 0;
//selection stuff, volatile because Interrupt changes them
volatile bool is_chapter_selected = false;
volatile bool is_page_selected = false;
volatile bool is_menu_open = false;//Open Menu with Interrupt on SW2
volatile bool has_selected = false;//Select Menu entry with Rotenc_SW
volatile bool is_menu_counter_reset = false; //reset Rotaryencoder count to start at the top of the menu

//Debounce the Rotary switch as the Menu is to fast and skips the page selection :(
long debounce_time = 15*1000;//15us (gets converted to ms)
volatile unsigned long last_micros;

String menu_chapter_names[] = {"Toolhead","Tempsens","Filamentsens","Settings"};//Main Menu entries
int menu_chapter_entries[] = {3,2,1,6};//count of pages in each chapter. Requierd to get the offset for page loading.
String menu_page_names[] = {"CNC","3DPrint","Headtimes","Tempsens1","Tempsens2","Filamentdia","Invrt Scn","Buz Vol","Ext Buz","Opto Out En","Chaos1","Factory Reset"};
int menu_page_entries[] = {2,2,0,0}; //count of paragrapth in each page. requierd to get the offset for loading.
String menu_paragrapth_names[] = {"RPM","Mtr Stat","NozTemp","NozFan","List Times", "Reset Timer","","",""}; //empty strings only needed if a Page is empty (But why is it there then!?)

//get size of total Array to know when to stop loading entries
int8_t menu_chapter_count = sizeof(menu_chapter_names)/sizeof(menu_chapter_names[0]);
int8_t menu_page_count = sizeof(menu_page_names)/sizeof(menu_page_names[0]);
int8_t menu_paragrapth_count = sizeof(menu_paragrapth_names)/sizeof(menu_paragrapth_names[0]);

String Axis_Names[8] = {"X1","Y1","Y2","Z1","Z2","AM","R1","R2"}; //X Axis, 2x Y-Axis, 2x Z-Axis, Ambient, 2x Reserve ADC Inputs, if needed elsewhere, remove from Array


//define Rotaryencoder
Encoder Rotenc(RotEnc_A,RotEnc_B);

//Buzzer Settings
LightChrono Buzzerclock_High;
LightChrono Buzzerclock_Low;
LightChrono Buzzerlock_Reset;
int buzzer_vol = 6;
int buzzer_fHigh = 15000;
int buzzer_fLow = 100;
int buzzer_highbeeps= 0;
int buzzer_hightime=0;
int buzzer_lowbeeps=0;
int buzzer_lowtime=0;
bool buzzer_lock = false;
int buzzer_offtime = 500;

void InitOLED(){ //Clear old Buffer,Rotate Display, Show single Pixel, Clear again, Lets go
displ.begin();
displ.clearDisplay();
displ.display();
displ.setRotation(2);
displ.drawPixel(10, 10, SSD1306_WHITE);
displ.display();
//delay(250);
displ.setTextSize(1);
    displ.setTextColor(WHITE);
    displ.setCursor(0,0);// Hight, Width
displ.clearDisplay();
displ.display();
}

void InitLED(){//Define LEDouputs and turn the off
    pinMode(LED1,OUTPUT);
    pinMode(LED2,OUTPUT);
    pinMode(LED3,OUTPUT);
    digitalWrite(LED1,LOW);
    digitalWrite(LED2,LOW);
    digitalWrite(LED3,LOW);
}

void Rotenc_Trig(){ //Interrupt for Menuselect
    has_selected = true;
}

void Button_Menu(){
    is_menu_open = true; //Button for Opening Menu, its pressed so Menu opens
}

void Button_Menu_Close(){//Stuff to reset when the menu is exited
    is_menu_counter_reset = false;
    is_menu_open = false;
    is_chapter_selected = false;
    is_page_selected = false;
    has_selected = false;
}

void InitButtons(){
    pinMode(Button1,INPUT_PULLUP); //Silkscreen SW2
    pinMode(Button2,INPUT_PULLUP);  //Silkscreen Sw3
    pinMode(RotEnc_Sw,INPUT_PULLUP); //Rotaryencoder Button
    //attachInterrupt(digitalPinToInterrupt(RotEnc_Sw),Rotenc_Trig,FALLING); //With interrupt the Menuselect is unusable :D
    attachInterrupt(digitalPinToInterrupt(Button1),Button_Menu,FALLING);    
    attachInterrupt(digitalPinToInterrupt(Button2),Button_Menu_Close,FALLING);

}

void InitBuzzer(){
    pinMode(Buzzer_out,OUTPUT);
    digitalWrite(Buzzer_out,LOW);
}

void InitRotEnc(){
Rotenc.write(0);
}


void buzzer_volume(int vol){ //16 is low, 14 is middle, 6 is LOUD 
    if (vol > 16)
    {
        vol = 16;
    }
    if (vol < 1)
    {
        vol = 1;
    }
    //analogWrite(Buzzer_out,vol*15); 255 beeing quiet, 0 beeing loud
    //Serial.println(vol);
    buzzer_vol = vol*15;
}

void buzzer_beep(int highbeeps, int timeperhigh, int lowbeeps, int timeperlow){
    
    //smaller then 0 not possible as it cant be sent via CAN, mainly sanitycheck if somethign lese calls the function
    if (highbeeps < 0){highbeeps = 0;} 
    if (lowbeeps < 0){lowbeeps = 0;} 
    
    //configure buzzer_offtime in steps of 10ms (500ms - 2s) 
    if (highbeeps == 60){buzzer_offtime = timeperhigh*10; highbeeps = 2;}
    
    //configure volume of Buzzer, 90 = loud, 250 = super quiet (<90 and the buzzer starts to get quieter, >250 and the piezzo doesnt vibrate)
    if (highbeeps == 61){buzzer_vol = timeperhigh; highbeeps = 2;}
    //Limit to 2x50 Beeps, who needs a total of 25s (100*255ms) of beeping anyway without something rechecking if the issues is still there?
    if (highbeeps > 50){highbeeps = 50;}
    if (lowbeeps > 50){lowbeeps = 50;}

    if (buzzer_offtime <500){buzzer_offtime = 500;}
    if (buzzer_offtime >2000){buzzer_offtime = 2000;}//WHO NEEDS A 2S OFFTIME !? sanity check mainly
    buzzer_highbeeps = highbeeps;
    buzzer_hightime = timeperhigh;
    buzzer_lowbeeps = lowbeeps;
    buzzer_lowtime = timeperlow;
}

void buzzer_buzz(){
    
    if (buzzer_highbeeps >0){
        if(!buzzer_lock){
            //Serial.print("BuzzHigh");
            buzzer_lock = true;
            
            analogWriteFrequency(Buzzer_out,4482);
            analogWrite(Buzzer_out,buzzer_vol);
            //Serial.print("Highbeeps: ");
            //Serial.println(buzzer_highbeeps);
            Buzzerlock_Reset.restart();
            Buzzerclock_High.restart();
        }
        if(Buzzerclock_High.hasPassed(buzzer_hightime)){
            analogWrite(Buzzer_out,0); 
            
        }
    }

    if ((buzzer_lowbeeps>0) and (buzzer_highbeeps == 0)){
        if(!buzzer_lock){
        //Serial.print("BuzzLow");
        buzzer_lock = true;
        
        analogWriteFrequency(Buzzer_out,512);
        analogWrite(Buzzer_out,buzzer_vol);
        //Serial.print("Lowbeeps: ");
        //Serial.println(buzzer_lowbeeps);
        Buzzerlock_Reset.restart();
        Buzzerclock_Low.restart();
        }

        if(Buzzerclock_Low.hasPassed(buzzer_lowtime)){
            analogWrite(Buzzer_out,0); 
        }

    }

    if(Buzzerlock_Reset.hasPassed(buzzer_offtime)){
        Buzzerlock_Reset.restart();
        //Serial.print(buzzer_highbeeps);
        //Serial.print(" ");
        //Serial.print(buzzer_lowbeeps);
        //Serial.print(" ");
        //Serial.println(buzzer_lock);
        if ((buzzer_lowbeeps > 0) and (buzzer_highbeeps == 0)){buzzer_lowbeeps = buzzer_lowbeeps -1;}
        if (buzzer_highbeeps > 0){buzzer_highbeeps = buzzer_highbeeps -1;}
        
        buzzer_lock = false;
        
    }
}

void emptyscreen(){
displ.clearDisplay();
displ.display();
}

int getRotaryencodercount(){
    int count_filt = 0;
    int encoder = Rotenc.read(); //Load value, then work on it, should lessen some issues (maybe?)
    count_filt = round(encoder*10)/40;
    //Serial.print(encoder);
    //Serial.println(count_filt);

 return count_filt;
}


void staticMenu(){
    int rotenc_count = getRotaryencodercount();
    has_selected = false;//reset before chekcing further

    if ((long)(micros()-last_micros)>= debounce_time){
    has_selected = !digitalRead(RotEnc_Sw);
    }

    last_micros = micros();

    Serial.printf("Last_micros: %d",last_micros);
    Serial.printf("Chapter: %d",menu_chapter);
    Serial.printf(" Page: %d",menu_page);
    Serial.printf(" Paragrath: %d",menu_paragrapth);
    
    Serial.print(" IS Chapter selected: ");
    Serial.print(is_chapter_selected);
    Serial.print(" IS Page selected: ");
    Serial.println(is_page_selected);

   // Serial.println(rotenc_count);
    displ.setCursor(0,0);// Hight, Width
    displ.print(menu_chapter);
    displ.print("-");
    displ.print(menu_page);
    displ.print("-");
    displ.println(menu_paragrapth);//add Linefeed to automaticly start writing on the next Line


    if(!is_chapter_selected)//Jump this if Chapter is selected
    { 
        //Limit the Chapterselection to whats actually there
        if (rotenc_count >= menu_chapter_count){
        Rotenc.write(0);
        }
        else if (rotenc_count < 0){
        Rotenc.write(0);
        }

        //Menulist
        for (int8_t i = rotenc_count; i < menu_chapter_count;++i)//Get Rotenc value, show the next entries. (128x64 will only show 3 entries, the rest will spill off the screen)
        {      
            if (i == rotenc_count)
            {
                displ.print(">");
            }
        displ.println(menu_chapter_names[i]);
        
        menu_chapter = rotenc_count;
        }
        //Select Menu
        if (has_selected){
            is_chapter_selected = true;
            Rotenc.write(0);
            has_selected = false;
        }
        
        return;
    }

    if(!is_page_selected and is_chapter_selected){//select the Page



        //load pages of selected chapter

        int8_t menu_pages_loading_offset = 0;
        int8_t menu_pages_loading_window = 0;
        int8_t menu_page_counter = 0;

        for (int8_t i = 0; i < menu_chapter; i++) //get offset by summing all privious menu_chapter_entries together
        {
            menu_pages_loading_offset = menu_pages_loading_offset + menu_chapter_entries[i];
        }
  
        menu_pages_loading_window = menu_pages_loading_offset + menu_chapter_entries[menu_chapter]; //offset+pages in this chapter
        menu_page_counter = menu_pages_loading_offset + rotenc_count; //set current selected page

        if(menu_page_counter >= menu_pages_loading_window){//Upperlimit
           // Serial.println("Pagecount OVER Window");
            Rotenc.write(0);
            menu_page_counter = menu_pages_loading_offset;
            }
            if (menu_page_counter < menu_pages_loading_offset){ //Lowerlimit
            //Serial.println("Pagecount UNDER Offset");
            Rotenc.write(0);
            menu_page_counter = menu_pages_loading_offset;
            }

        for (int8_t i = menu_page_counter; i < menu_pages_loading_window; i++) //List all pages in this Chapter
        {
            

            if (i == menu_page_counter)
            {
                displ.print(">");
            }

            displ.println(menu_page_names[i]);
            
            menu_page = rotenc_count;

            //Serial.print("Offset: ");
            //Serial.print(menu_pages_loading_offset);
            //Serial.print(" Window: ");
            //Serial.print(menu_pages_loading_window);
            //Serial.print(" Pagecounter: ");
            //Serial.print(menu_page_counter);
            //Serial.print(" Rotenc: ");
            //Serial.println(rotenc_count);  
        }
        
         //Select Menu
        if (has_selected){
            is_page_selected = true;
            Rotenc.write(0);
            has_selected = false;
        }
        
    return;
    }

    if(is_page_selected and is_chapter_selected){ //select the Paragrapth
        int8_t menu_paragrapth_loading_offset = 0;
        int8_t menu_paragrapth_loading_window = 0;
        int8_t menu_paragrapth_counter = 0;

        for (int8_t i = 0; i < menu_page; i++)//get paragrapth offset by summing all privious menu_page_entries together
        {
            menu_paragrapth_loading_offset = menu_paragrapth_loading_offset + menu_page_entries[i];
        }

        menu_paragrapth_loading_window = menu_paragrapth_loading_offset+menu_page_entries[menu_page]; //offset + current page
        menu_paragrapth_counter = menu_paragrapth_loading_offset + rotenc_count; //set current selected paragrpath

        if (menu_paragrapth_counter >= menu_paragrapth_loading_window){//Upperlimit
            Rotenc.write(0);
            menu_paragrapth_counter = menu_paragrapth_loading_offset;
        }
        if (menu_paragrapth_counter < menu_paragrapth_loading_offset){ //Lowerlimit
            Rotenc.write(0);
            menu_paragrapth_counter = menu_paragrapth_loading_offset;

        }
        for (int8_t i = menu_paragrapth_counter; i < menu_paragrapth_loading_window; i++)//list all Paragrapths 
        {
                if (i == menu_paragrapth_counter){
                    displ.print(">");
                }

            displ.println(menu_paragrapth_names[i]);
            menu_paragrapth = rotenc_count;
        }
        
       has_selected = false;
    }


    //Whats following is a nightmare of If cases to build the Menustructure. If you have a better way, fix it
if(menu_chapter == 0 and menu_page == 0 and menu_paragrapth == 0){ //Toolhead-CNC-RPM
    Serial.print("Toolhead-CNC-RPM selected");
}




/*
String menu_chapter_names[] = {"Toolhead","Tempsens","Filamentsens","Settings"};//Main Menu entries
String menu_page_names[] = {"CNC","3DPrint","Headtimes","Tempsens1","Tempsens2","Filamentdia","Invrt Scn","Buz Vol","Ext Buz","Opto Out En","Chaos1","Factory Reset"};
String menu_paragrapth_names[] = {"RPM","Mtr Stat","NozTemp","NozFan","List Times", "Reset Timer","","",""}; //empty strings only needed if a Page is empty (But why is it there then!?)


*/

        
    //Serial.print("Rotenc: ");
    //Serial.println(Rotenc.read());
    has_selected = false;
}


void update_oledscreen() {
    displ.clearDisplay();

    //Serial.print("Menu open: ");
   // Serial.println(is_menu_open);

    if (!is_menu_open)
    {
        displ.setCursor(10,0);
        displ.print("Tmax Axis: ");
        displ.print(Axis_Names[GethighestTemp_Index()]);
        displ.print(" - ");
        displ.print(GethighestTemp_C());
        displ.print("C");
        
    }
    else
    {   
        if(!is_menu_counter_reset)
        {
            Rotenc.write(0);
            is_menu_counter_reset = true;
            Serial.println("Menu Rotenc reset");
        }
        //Serial.println("Menu selected");
        staticMenu();
    }
    noInterrupts();
    has_selected = false;
    interrupts();
    
}

void draw_display(){//Metro routine calls draw_display every 250ms to update Screen
    if (displaydirty){
        displ.display();
    }
}

