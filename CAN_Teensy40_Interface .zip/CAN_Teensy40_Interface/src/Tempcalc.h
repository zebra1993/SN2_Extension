#ifndef MODULE_ADC_H_
#define MODULE_ADC_H_
enum LinearTempSens {
    X_Axis_1,   //0 Channel 1
    Y_Axis_1,   //1 Channel 2
    Y_Axis_2,   //2 Channel 3
    Z_Axis_1,   //3 Channel 4
    Z_Axis_2,   //4 Channel 5
    Ambient,    //5 Channel 6   
    Spare_1,    //6 Channel 7
    Spare_2,    //7 Channel 8
};

void InitADC();
int GetTemp(LinearTempSens ch);
float GetVoltage(LinearTempSens ch);
int GethighestTemp_C();
int GethighestTemp_Index();



#endif