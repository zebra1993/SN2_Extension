#ifndef MODULE_FRAM_H_
#define MODULE_FRAM_H_

enum ToolHeadTimers{ //4 Byte total, store seconds, calculate the rest from there
    FilamentPrinterHeadTimer,
    CNCCutterHeadTimer,
    LaserCutterHeadTimer,
    RotaryModuleTimer,
    OptionHead1Timer,
    OptionHead2Timer,
    OptionHead3Timer
};


//(4Kbit= 512byte = 128 slots) (maybe upgrade to 64kbit (2048 slots?)
enum FRAMAdress32{//Data is stored in 32bit chunks, offset is in save/load functions
FilamentPrinterHead, 
CNCCutterHead,       
LaserCutterHead,        
RotaryModule,           
OptionHead1,
OptionHead2,
OptionHead3,

HasInit = 127//Last Adress

};



void InitFRAM();
uint16_t GetToolTime_Min(ToolHeadTimers tim);
uint8_t Getcount();
void Setcount(uint8_t count);

uint32_t GetDword(FRAMAdress32 Adress);
void SetDword(FRAMAdress32 Adress, uint32_t Data);

void framtest();













#endif