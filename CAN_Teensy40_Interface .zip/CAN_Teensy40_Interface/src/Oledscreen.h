#ifndef MODULE_OOLEDSCREEN_H_
#define MODULE_OOLEDSCREEN_H_


//OLED Related stuff

void InitOLED();
void InitRotEnc();
void InitLED();
void InitButtons();
void InitBuzzer();
void sethomescreen();
int  getRotaryencodercount();
void buzzer_beep(int highbeeps, int timeperhigh, int lowbeeps, int timeperlow);
void buzzer_frequ(int Count);
void staticMenu();
void buzzer_volume(int vol);
void update_oledscreen();
void draw_display();
void buzzer_buzz();
#endif