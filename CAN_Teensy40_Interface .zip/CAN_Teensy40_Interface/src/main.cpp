//Libaries
#include <Arduino.h>
#include <FlexCAN_T4.h>
#include <Adafruit_MCP3008.h>
#include <FastLED.h>
#include <LightChrono.h>

//Custom Headers
#include "Tempcalc.h"
#include "Datastorage.h"
#include "Oledscreen.h"
#include "Module_Pins.h"

//Adressabel RGB LED
//#define RGB_DATA_PIN 6 //Defined in Modules_Pins.h
#define NUM_LEDS_PER_STRIP 8
#define NUM_STRIPS 1
CRGB leds[NUM_LEDS_PER_STRIP * NUM_STRIPS];
bool updateLEDs = true;

LightChrono drawscreenChrono;//use Metro as a scheduler, every 250ms update the screen
LightChrono heartbeatLED;//blink LED every 500 ms

//CAN Bus
FlexCAN_T4<CAN2, RX_SIZE_256, TX_SIZE_16> canSN;
FlexCAN_T4<CAN1, RX_SIZE_256, TX_SIZE_16> canMod;

 CAN_message_t CANmsg;
 CAN_message_t msgMod;

 

void canSniff(const CAN_message_t &msg) {
  //Bus 2 = Snapmaker CAN0, Bus 1 = Extension CAN1 (See Canbus declaration (L25,L26))
  Serial.print("Bus: ");Serial.print(msg.bus);
  Serial.print("  MB "); Serial.print(msg.mb);
  Serial.print("  OVERRUN: "); Serial.print(msg.flags.overrun);
  Serial.print("  LEN: "); Serial.print(msg.len);
  Serial.print(" EXT: "); Serial.print(msg.flags.extended);
  Serial.print(" TS: "); Serial.print(msg.timestamp);
  Serial.print(" ID: "); Serial.print(msg.id, HEX);
  Serial.print(" Buffer: ");
  for ( uint8_t i = 0; i < msg.len; i++ ) {
    Serial.print(msg.buf[i], HEX); Serial.print(" ");
  } Serial.println();
}

void canHandle(const CAN_message_t &msg){
  //Not much gogin on, but call functions as needed, switchcase for all the used IDs, per Interface?
  if (msg.bus == 1){
    //Serial.println("Extension Msg");
    if (msg.id != 21){ //Prevent a node form accidently sending a Endstop reply to the printer (The printer doesnt look for them afaik though as the Homing is the only time they are used to get the references)
    canSN.write(msg);}
    canSniff(msg);
  }
  if (msg.bus == 2){canMod.write(msg);
  canSniff(msg);
  }

  //canSniff(msg);

  //Reactions to incoming messages
  //ID2000
  int Highbeeps = 0;
  int Lowbeeps = 0;
  int Hightime = 0;
  int Lowtime = 0;
  //ID2001
  int nrLED = 0;
  int clrRD = 0;
  int clrGN = 0;
  int clrBL = 0;

  switch (msg.id)
  {
    //Datapacket: #Highbeed, High_Duration, #Lowbeep, Low_Duration  Duration is limited to 255ms
    case 2000://Beep Buzzer over CANbus, first 4 Bytes used, rest is ignored
      for ( uint8_t i = 0; i < msg.len; i++ ) {
        switch (i)
        {
        case 0:
        Highbeeps = msg.buf[i];
          break;
          case 1:
          Hightime = msg.buf[i];
          break;
          case 2:
          Lowbeeps = msg.buf[i];
          break;
          case 3:
          Lowtime = msg.buf[i];
          break;
        default:
          break;
        }
    }
      buzzer_beep(Highbeeps,Hightime,Lowbeeps,Lowtime);
      break;
    case 2001://Set Adressable RGBLED to Color
    
      //Datapacket: LED#, RED, GREEN, BLUE 
      for (size_t i = 0; i < msg.len; i++)
      {
        switch (i)
        {

          case 0:
          nrLED = msg.buf[i];
          break;
          case 1:
          clrRD = msg.buf[i];
          break;
          case 2:
          clrGN = msg.buf[i];
          break;
          case 3:
          clrBL = msg.buf[i];
          break;
          default:
          break;

        }
      }
     // Serial.print("MSG.Len: ");
      //Serial.print(msg.len);
      //Serial.print(" NrLED: ");
      //Serial.print(nrLED);
      //Serial.print(" clrRD: ");
      //Serial.print(clrRD);
      //Serial.print(" clrGN: ");
      //Serial.print(clrGN);
      //Serial.print(" clrBL: ");
      //Serial.println(clrBL);

      leds[nrLED] = CRGB(clrRD,clrGN,clrBL);
      updateLEDs = true;
      break;
      
    default:
    break;
  }



}

void InitCAN(){
  //Interaface to Snapmaker
  canSN.begin();
  canSN.setClock(CLK_60MHz);
  canSN.setBaudRate(500000);
  canSN.setMaxMB(16);
  canSN.enableFIFO();
  canSN.enableFIFOInterrupt();
  canSN.onReceive(canHandle);
  canSN.mailboxStatus();
  //Interface to Extension
  canMod.begin();
  canMod.setClock(CLK_60MHz);
  canMod.setBaudRate(500000);
  canMod.setMaxMB(16);
  canMod.enableFIFO();
  canMod.enableFIFOInterrupt();
  canMod.onReceive(canHandle);
  canMod.mailboxStatus();
}


void setup(void) {
  Serial.begin(115200); delay(5000);
 
  InitCAN();
  InitFRAM(); //Custom Function for Datastorage (64Kbit FRAM)
  InitADC(); //Custom Function for Temperature Checks
  InitOLED(); //Custom Function for OLED screen 
  InitRotEnc();
  InitLED();
  InitBuzzer();
  InitButtons();
  pinMode(7,OUTPUT);
   
  FastLED.addLeds<NUM_STRIPS, WS2812B, RGB_DATA_PIN, GRB>(leds, NUM_LEDS_PER_STRIP);
  Serial.println("Init done");
}


int count = 50;
int32_t canmsgid = 0;
CAN_message_t msg;




void loop() {
  canSN.events();
  canMod.events();
  CAN_message_t msg;
  if (updateLEDs){FastLED.show(); updateLEDs = false;}//THIS DOESNT WORK CORRECTL; NO CLUE WHY!! LED7 just stays dark!?
  
  //digitalWrite(RGB_DATA_PIN,HIGH); //Check runspeed of OLED routine (without Screen update, 2ms, with update 23)
  //update_oledscreen();

  if (drawscreenChrono.hasPassed(500)){//Metro routine calls draw_display every 250ms to update Screen
  drawscreenChrono.restart();
  //draw_display();
  msg.id = 0x16;
  msg.len = 1;
  msg.buf[0] = 128;
  canSN.write(msg);
  Serial.println("CanMSG");
  }
  
  if (heartbeatLED.hasPassed(500)){
    heartbeatLED.restart();
    updateLEDs = true;//regualr refresh for ALEDs
    digitalWrite(LED1,!digitalRead(LED1));
  }
  
  buzzer_buzz();//run through buzzerroutine (NONE BLOCKING HAHA!!!)

  digitalWrite(7,!digitalRead(7));

}