/* 
All the informations on this screen are CANbus only (WIth code inside the Controller more could be exposed)
SN-CAN and 24V coming from the main module. CANbus is ended in Module with interal CAN1 and CAN2 is used for other custom modules.
Module will have 1x 120Ohm Resistor, the other Termination resistor has to be fitted on the last module of the Chain. 

Each module has a CAN_IN (f) and CAN_OUT (m) DB9 with standart Pinarangement
Pin 1 Res
Pin 2 CAN_L 
Pin 3 CAN_GND
Pin 4 Res
Pin 5 CAN_Shld
Pin 6 GND
Pin 7 CAN_H
Pin 8 Res
Pin 9 24V+



Screen is navigated with a rotary encoder with center click and a Back button (like other 3d printers)
A Toolhead timer could be implemented with a EEPROM/flash storage or FRAM 
Timers would go by the nearest second as the Temperature and Spindle on/off are sent over CANbus
Lasermodule would need to get a simmilar message as the Laser is controlled directly without CAN.

Option: Add a MCP23017 I2C (16 Pins) IO Expander (4 Pins on Teensy(I2C +2x Interupt))
5-10 Pins are made available for external use, dont know yet which ones or if there is need at all. Either Push-in or Screw termnials, no Dupont wires to keep it sturdy
IOPins are limited to a total of 25 mA. Add external circuitry to drive anyhting bigger then a 5mm LED



OLED Mainscreen:
-Current temp of Nozzle/ Target temp
-CNC RPM
-Filament runout detection
-Hightprobe status
-Limitswitch (which switch has triggerd)
-Time since turn on?
-Temperature Temp probes avg, max


Menus are visible on the top left with Index-Subindex

Index 1-0 Change Temperature/ Spindlespeed
  if 3D Toolhead is installed
    1 Change Temperature : 0-300°C
    2 Change Fan  : 0-100% (Dont play with it if you dotn want to rist damage to your hotend)

  if CNC Toolhead is installed
    1 Change Spindlespeed : 20-100% (Default min is 50% in Luban)
    2 Turn on IO Pin on Module if spinlde is running : Yes, No
    3 Delay of IO Pin to turn off after Spindle has stopped : 0-20s   

Index 8-0 Aftermarket Filamentsensor
    1 Alert state : Normaly Open, Normaly Closed
    2 Impulses per 10mm : 1-255
    3 Timeout before Printer is paused : 0-10s
    4 Action when Problem is detected : M600,  

Index 9-0 Module Settings
    1 Brightness : Min, Default, Bright (default beeing 50-60% to spare the pixels a bit)
    2 Invert screen : On, Off
    3 Buzzer Vol : Low, Default, Loud
    4 External Buzzer : Yes, No (Simple IO Pin, no PWM)
    5
    6


Structure:
Chapter
  -Page
    -Paragrapth
    -Paragrapth
  -Page
    -Paragrapth

Chapter
  -Page
    -Paragrapth




Canbus Message for Controlling coords
2Byte = 65k mm
X 2 Byte
Y 2 Byte
Z 2 Byte
A
*/